package com.cg.model;



import java.util.List;

import com.cg.bean.Invoice;
import com.cg.bean.Product;

public class InvoiceProductModel {

	Invoice invoiceObject;
	List<Product> productsList;

	public InvoiceProductModel() {
	}

	public InvoiceProductModel(Invoice invoiceObject, List<Product> productsList) {
		super();
		this.invoiceObject = invoiceObject;
		this.productsList = productsList;
	}

	public Invoice getInvoiceObject() {
		return invoiceObject;
	}

	public void setInvoiceObject(Invoice invoiceObject) {
		this.invoiceObject = invoiceObject;
	}

	public List<Product> getProductsList() {
		return productsList;
	}

	public void setProductsList(List<Product> productsList) {
		this.productsList = productsList;
	}

	@Override
	public String toString() {
		return "productModel [invoiceObject=" + invoiceObject + ", productsList=" + productsList + "]";
	}

}
