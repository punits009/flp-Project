package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Cart;
import com.cg.bean.Discount;
import com.cg.bean.Product;
import com.cg.bean.User1;
import com.cg.bean.Wishlist;
import com.cg.dao.CartDAO;
import com.cg.dao.DiscountDAO;
import com.cg.dao.ProductDAO;
import com.cg.dao.User1DAO;
import com.cg.dao.WishlistDAO;
import com.cg.exception.ApplicationException;
import com.cg.exception.InvalidInputException;
import com.cg.exception.ProductUnavailableException;
import com.cg.model.Excep;

@Service
@Transactional
public class IProductServiceImpl implements IProductService {

	User1 user;
	// Review review;
	Product product;

	Cart cart;

	@Autowired
	private User1DAO customerRepo;

	@Autowired
	private CartDAO cartRepo;

	@Autowired
	private DiscountDAO discountDao;

	// @Autowired
	// private AddressRepo addressRepo;

	@Autowired
	private WishlistDAO wishlistRepo;

	@Autowired
	ProductDAO productRepo;

	@Override
	public Product getProduct(int productID) {

		return productRepo.getProduct(productID);

	}

	@Transactional(readOnly = true)
	public Product getById(int id) {
		Optional<Product> product = productRepo.findById(id);
		if (product.isPresent()) {
			return product.get();
		} else {
			throw new ApplicationException("No Product Exists");
		}
	}

	// wishlist.............................................

	@Override
	public Excep addProductToWishlist(int userId, int productId) throws InvalidInputException {

		product = productRepo.getOne(productId);
		user = customerRepo.getOne(userId);

		Wishlist wishlist1 = wishlistRepo.findByuser(user);

		if (wishlist1 == null) {
			Wishlist wishlist = new Wishlist();
			System.out.println("Inside if");
			List<Product> products = new ArrayList<Product>();
			products.add(product);
			wishlist.setUser(user);
			wishlist.setProducts(products);
			System.out.println(wishlist.getProducts());
			wishlist.setName("My Wishlist");
			 wishlistRepo.save(wishlist);
			   Excep ex = new Excep();
			   ex.setStatus("Product added to wishlist");
			   return ex;
		} else {
			List<Product> productList = new ArrayList<Product>();
			productList = wishlist1.getProducts();
			//productList.add(product);
			//wishlist1.setProducts(productList);
			int index= productList.indexOf(product);
			  System.out.println(index);
			  if(index==-1) {
			  productList.add(product);
			  wishlist1.setProducts(productList);
			  wishlistRepo.save(wishlist1);
			  Excep ex = new Excep();
			  ex.setStatus("Product added to wishlist");
			   return ex;
			  }else {
			  // System.out.println("Product already exist in");
			  Excep ex = new Excep();
			  ex.setStatus("Product already exists in wishlist");
			   return ex;
			  }
			  }
		}

	@Override
	public boolean removeProductFromWishlist(int userId, int productId) throws InvalidInputException {
		product = productRepo.getOne(productId);
		user = customerRepo.findByuserId(userId);
		Wishlist wishlist = wishlistRepo.findByuser(user);
		List<Product> productsList = wishlist.getProducts();
		productsList.remove(product);
		wishlist.setProducts(productsList);

		wishlistRepo.save(wishlist);
		return true;
	}

	@Override
	public List<Product> getWishlist(int userId) throws InvalidInputException {
		Wishlist wishlist = new Wishlist();
		try {
			user = customerRepo.findByuserId(userId);
			wishlist = wishlistRepo.findByuser(user);
		} catch (Exception e) {
			e.getMessage();
		}
		return wishlist.getProducts();
	}

	// cart......................................

	@Override

	public Excep addProductToNewCart(int userId, int productId)
			throws ProductUnavailableException {
		product = productRepo.getOne(productId);
		user = customerRepo.getOne(userId);
		Cart cart1 = cartRepo.findByuser(user);
		if (cart1 == null)
		{
			Cart cart = new Cart();
			System.out.println("Inside if");
			List<Product> products = new ArrayList<Product>();
			products.add(product);
			cart.setUser(user);
			cart.setProducts(products);
			List<Double> amount = new ArrayList<Double>();
			Double discount = this.checkDiscountOnProductById(product.getProductID());
			Double finalamount = this.applyDiscount(product.getPrice(), discount);
			amount.add(finalamount);
			cart.setAmount(amount);
			  cartRepo.saveAndFlush(cart);
			  Excep ex = new Excep();
			   ex.setStatus("Product added to cart");
			   return ex;
		}
		else
		{
			List<Product> productList = new ArrayList<Product>();
			productList = cart1.getProducts();
			 int index= productList.indexOf(product);
			  if(index==-1) {
			productList.add(product);
			cart1.setProducts(productList);
			List<Double> amount = new ArrayList<Double>();
			amount = cart1.getAmount();
			Double discount = this.checkDiscountOnProductById(product.getProductID());
			Double finalamount = this.applyDiscount(product.getPrice(), discount);
			amount.add(finalamount);
			cart1.setAmount(amount);
			  cartRepo.saveAndFlush(cart1);
			   Excep ex = new Excep();
			  ex.setStatus("Product added to cart");
			  return ex;
			  }else {
			   //System.out.println("Product already exist");
			   Excep ex = new Excep();
			   ex.setStatus("Product already exists in cart");
			    return ex;
			  }
			  }
			  }

	@Override

	public List<Product> getAllProductsFromCart(int userId) throws InvalidInputException {

		Cart cart;

		user = customerRepo.getOne(userId);

		cart = cartRepo.findByuser(user);

		return cart.getProducts();

	}

	@Override

	public boolean removeProductFromCart(int userId, int productId) throws InvalidInputException {

		product = productRepo.getOne(productId);

		user = customerRepo.findByuserId(userId);

		Cart cart = cartRepo.findByuser(user);

		List<Product> productsList = cart.getProducts();

		Integer index = productsList.indexOf(product);
		
		productsList.remove(product);
		
		List<Double> discounts = cart.getAmount();
		
		System.out.println(index);
		System.out.println(discounts.toString());
		
		discounts.remove(discounts.get(index));

		
		cart.setAmount(discounts);
		cart.setProducts(productsList);

		// Wishlist w=new Wishlist();

		// product.setWishlist(null);

		cartRepo.save(cart);

		return true;

	}
	
	
	@Override

	 public boolean removeAllFromCart(int userId)throws InvalidInputException {

	 user = customerRepo.findByuserId(userId);

	 Cart cart= cartRepo.findByuser(user);

	 int id=cart.getCartId();

	 System.out.println(id);

	 cartRepo.deleteById(id);

	 return true;

	 }
	

	// discount.................................................
	@Transactional(readOnly = true)
	public Double checkDiscountOnProductById(Integer productId) {
		// TODO Auto-generated method stub
		Product product = productRepo.findById(productId).get();
		Double discount = discountDao.checkDiscountOnProductById(product);
		if (discount == null) {
			return 0.0;
		} else {
			return discount;
		}
	}

//	@Transactional(readOnly = true)
//	public Integer applyDiscountOnProduct(Integer productId) {
//		Product product = productRepo.findById(productId).get();
//		int discount = discountDao.checkDiscountOnProductById(product);
//		int price = productRepo.getProductPrice(productId);
//		return price - discount;
//	}
	
	@Transactional(readOnly=true)
	public Double applyDiscount(Double productprice, Double discount) {
		Double dis = (productprice*discount)/100;
		return productprice-dis;
	}
	
	
}
