package com.cg.service;

import com.cg.model.PasswordEntity;

public interface passwordService {

	public PasswordEntity changepassword(PasswordEntity entity);
}
