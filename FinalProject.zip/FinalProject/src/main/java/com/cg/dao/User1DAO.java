package com.cg.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.cg.bean.User1;

public interface User1DAO extends JpaRepository<User1, Integer> {
	@Query("select u.password from User1 u where u.emailid=?1")
	public String getUserPassword(String emailId);

	@Query("select u from User1 u where u.emailid=?1")
	public User1 existsByEmail(String emailId);

	@Transactional
	@Modifying
	@Query("update User1 u set u.password=?2 where u.emailid=?1")
	public void updatepassword(String email, String password);

	public User1 findByuserId(int userId);
	
	@Query("Select u from User1 u" )
	List<User1> findAllUser();
	
	@Query("select u from User1 u where u.userId=?1")
	List<User1> findByUserId(int UserId);
	
	@Query("select u From User1 u  where u.emailid=?1")
	public User1 getuser(String email);
}
