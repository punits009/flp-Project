package com.cg.dao;



import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.bean.User1;


@Repository
public interface User1DAO1 {

	public List<User1> user(int orderid);

	User1 getUser(int userid);
}
