package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.bean.Merchant;

public interface TPMerchantDao extends JpaRepository<Merchant, Integer> {

	@Query("SELECT m FROM Merchant m WHERE m.status='Disapproved' order by m.company")
	public List<Merchant> findTPMerchant(@Param("status") String status);
}
